

<?php $__env->startSection('title', 'Blog List Page'); ?>

<?php $__env->startSection('content'); ?>
<div>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">

        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary"><a href="/" class="text-decoration-none">Post List</a> </h6>
            <button class="btn btn-sm btn-info" id="add"><i class="fa fa-plus"> <a class="text-white text-decoration-none" href="<?php echo e(route('post.add_post')); ?>">Add Post</a></i></button>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#SL</th>
                            <th>Parent Category</th>
                            <th>Sub Category</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Thumbnail</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($posts)): ?>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->category_name ?? 'N/A'); ?></td>
                                    <td><?php echo e($item->subcategory_name ?? 'N/A'); ?></td>
                                    <td><?php echo e($item->title ?? 'N/A'); ?></td>
                                    <td><?php echo Str::limit($item->description, 100, ' .....'); ?></td>
                                    <td><img style="width: 50px;" src="<?php echo e(URL::to( 'blogImg') . '/' . $item->thumbnail); ?>" alt=""></td>
                                    <td class="text-center">
                                        <?php echo $item->is_active ? '<span class="badge badge-success">Active </span>' : '<span class="badge badge-danger">In-Active </span>'; ?>

                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('post.show_post', $item->id )); ?>" class="fa fa-eye text-info text-decoration-none"></a>
                                        <a href="<?php echo e(route('post.edit_post', $item->id )); ?>" class="fa fa-edit mx-2 text-warning text-decoration-none"></a>
                                        <a href="<?php echo e(route('post.destroy_post', $item->id )); ?>" onclick="alert('Are you sure!')"  class="fa fa-trash text-danger text-decoration-none"></a>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('assets/backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/backend/css/currency/currency.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('assets/backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('assets/backend/libs/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thaise-saloon\resources\views/post/postList.blade.php ENDPATH**/ ?>