

<?php $__env->startSection('title', 'Post View'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <button class="btn btn-success m-2"><a class="text-white decoration-none" href="<?php echo e(route('post.post_list')); ?>">Back</a></button>
     
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered"  width="100%" cellspacing="0">
                    <tbody>
                        <tr class="borderd bg-danger text-white">
                            <th colspan="2">
                                <h4>
                                    Post Information
                                </h4>
                            </th>
                        </tr>

                        <tr>
                            <th>Post Title</th>
                            <td><?php echo e($post->title); ?></td>
                        </tr>

                        <tr>
                            <th>Post Thumbnail</th>
                            <td><img style="width: 150px;" src="<?php echo e(URL::to( 'blogImg') . '/' . $post->thumbnail); ?>" alt=""></td>
                        </tr>

                        <tr>
                            <th>Post Description</th>
                            <td><?php echo e($post->description); ?></td>
                        </tr>

                        <tr>
                            <th>Post Status</th>
                            <td class="text-left">
                                <?php echo $post->is_active ? '<span class="badge badge-success">Active </span>' : '<span class="badge badge-danger">In-Active </span>'; ?>

                            </td>
                        </tr>
                  
                    </tbody>
                </table>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thaise-saloon\resources\views/post/viewpost.blade.php ENDPATH**/ ?>