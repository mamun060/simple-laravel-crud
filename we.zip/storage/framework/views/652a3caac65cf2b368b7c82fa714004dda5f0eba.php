

<?php $__env->startSection('title', 'Add Sub Category page'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="text-dark">Add Sub Category Information</h2>
    <form action="<?php echo e(route('subcategory.subcategory_update', $subCategory->id )); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-12">
                <select name="category_id" id="" class="form-control text-dark">
                    <?php if(isset($categories)): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"> <?php echo e($category->category_name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                
                </select>
            </div>
                <div class="col-md-6">
                    <label for="name">Category Name</label>
                    <input id="name"  name="category_name" type="text" class="form-control" value="<?php echo e($subCategory->subcategory_name); ?>">
                </div>
                <div class="col-md-6">
                    <label for="name">Category Description</label>
                    <input id="name"  name="category_description" type="text" class="form-control" value="<?php echo e($subCategory->subcategory_description); ?>">
                </div>
                <div class="col-md-12 mt-2 mb-2">
                    <label for="category_image">Category Thumbnail</label>
                    <input name="category_image" id="category_image" type="file">
                </div>
                <div class="col-md-12">
                    <label for="">Category Status</label>
                     <div class="d-flex">
                         <div class="mr-2">
                            <label for="active">Active</label>
                            <input type="radio" name="isActive" id="active" value="1" checked>
                         </div>
                         <div>
                            <label for="inactive">Inactive</label>
                            <input type="radio" name="isActive" id="inactive" value="0">
                         </div>
                     </div>
                </div>
                <div class="col-md-12">
                    <input class="btn btn-success" type="submit" value="Submit">
                </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thaise-saloon\resources\views/category/editsubcategory.blade.php ENDPATH**/ ?>