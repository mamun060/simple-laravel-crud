

<?php $__env->startSection('title', 'add comment'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <div class="container">
            <form action="<?php echo e(route('comment.store_comment')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <label for="post_id">Select Post</label>
                        <select name="post_id" id="post_id" class="form-control">
                            <?php if(isset($posts)): ?>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($post->id); ?>"><?php echo e($post->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="name">Name</label>
                        <input name="name" type="text" class="form-control" id="name">
                    </div>
                    
                    <div class="col-md-6">
                        <label for="email">Email</label>
                        <input id="email" name="email" type="email" class="form-control">
                    </div>

                    <div class="col-md-12">
                        <label for="comment">Comment</label>
                        <textarea name="comment" id="comment" cols="30" rows="5" class="form-control"></textarea>
                    </div>

                    <div class="col-md-12 mt-2">
                        <label for="">Status</label>
                         <div class="d-flex">
                             <div class="mr-2">
                                <label for="active">Active</label>
                                <input type="radio" name="is_active" id="active" value="1" checked>
                             </div>
                             <div>
                                <label for="inactive">Inactive</label>
                                <input type="radio" name="is_active" id="inactive" value="0">
                             </div>
                         </div>
                    </div>

                    <div class="col-md-12">
                        <input class="btn btn-success" type="submit" value="Submit">
                    </div>

                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thaise-saloon\resources\views/comment/addcomment.blade.php ENDPATH**/ ?>