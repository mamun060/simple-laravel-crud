

<?php $__env->startSection('title', 'add post'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <div class="container">
            <h2>Edit Post Informaiton</h2>
            <form action="<?php echo e(route('post.update_post', $post->id )); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-md-6">
                        <label for="category">Parent Category</label>
                        <select name="category_id" id="category" class="form-control">
                            <?php if(isset($categories)): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="subcategory">Sub Category</label>
                        <select name="subcategory_id" id="subcategory" class="form-control">
                            <?php if(isset($subcategories)): ?>
                                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->subcategory_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="title">Post Title</label>
                        <input name="title" type="text" class="form-control" id="title" value="<?php echo e($post->title); ?>">
                    </div>

                    <div class="col-md-6 d-flex align-items-end">
                        

                        <div>
                            <label for="thumbnail">Post Thumbnail</label>
                            <input name="new_thumbnail" id="thumbnail" type="file" class="form-control" value="<?php echo e($post->thumbnail); ?>">
                        </div>
                    </div>

                    <div class="col-md-12">
                        <label for="description">Post Content</label>
                        <textarea name="description" id="description" cols="30" rows="5" class="form-control"><?php echo e($post->description); ?></textarea>
                    </div>

                    <div class="col-md-2 mt-2">
                        <label for="">Post Status</label>
                         <div class="d-flex">
                             <div class="mr-2">
                                <label for="active">Active</label>
                                <input type="radio" <?php echo e($post->is_active ? 'checked' : ''); ?> name="is_active" id="active" value="1">
                             </div>
                             <div>
                                <label for="inactive">Inactive</label>
                                <input type="radio" <?php echo e($post->is_active ? '' : 'checked'); ?> name="is_active" id="inactive" value="0">
                             </div>
                         </div>
                    </div>

                    <div class="col-md-6 mt-2">
                        <label for="">Post Publish</label>
                         <div class="d-flex">
                             <div class="mr-2">
                                <label for="active">Yes:</label>
                                <input type="radio" name="is_publish" id="active" value="1" checked>
                             </div>
                             <div class="ml-2">
                                <label for="inactive">NO:</label>
                                <input class="ml-1" type="radio" name="is_publish" id="inactive" value="0">
                             </div>
                         </div>
                    </div>

                    <div class="col-md-12">
                        <input class="btn btn-success" type="submit" value="Submit">
                    </div>

                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thaise-saloon\resources\views/post/editpost.blade.php ENDPATH**/ ?>